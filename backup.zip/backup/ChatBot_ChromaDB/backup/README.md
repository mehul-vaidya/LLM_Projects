# Chat-With-Your-Data-Chatbot
Chat with Your Data Chatbot using Langchain, ChromaDB, Sentence Transformers, and LaMiNi LM Model. This Chatbot is completely powered by Open Source Models. No OpenAI key is required.
